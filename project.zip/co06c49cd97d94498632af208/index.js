let scoreHome = document.getElementById("score-home")
let scoreHomeCount = 0

let scoreGuest = document.getElementById("score-guest")
let scoreGuestCount = 0



function addOneHome() {
   scoreHomeCount += 1 
   scoreHome.textContent = scoreHomeCount
    
}


function addTwoHome() {
      scoreHomeCount += 2
   scoreHome.textContent = scoreHomeCount
}
   

function addFourHome() {
      scoreHomeCount += 4 
   scoreHome.textContent = scoreHomeCount
    
}


function addSixHome() {
      scoreHomeCount += 6 
   scoreHome.textContent = scoreHomeCount
    
}

function addOneGuest() {
    
   scoreGuestCount += 1 
   scoreGuest.textContent = scoreGuestCount
}
   
   
   
function addTwoGuest() {
    
   scoreGuestCount += 2
   scoreGuest.textContent = scoreGuestCount
    
}

function addFourGuest() {
    
   scoreGuestCount += 4 
   scoreGuest.textContent = scoreGuestCount
    
}

function addSixGuest() {
    
   scoreGuestCount += 6 
   scoreGuest.textContent = scoreGuestCount
    
}

